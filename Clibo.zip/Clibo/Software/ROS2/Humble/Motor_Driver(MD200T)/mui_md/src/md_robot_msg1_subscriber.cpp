#include "rclcpp/rclcpp.hpp"
#include "mui_md/msg/md_robot_msg1.hpp"  // 새로 정의한 메시지 헤더

class MdRobotMsg1Subscriber : public rclcpp::Node
{
public:
  MdRobotMsg1Subscriber() : Node("md_robot_msg1_subscriber")
  {
    subscription_ = this->create_subscription<mui_md::msg::MdRobotMsg1>(
      "md_robot_msg1_topic", 10,
      std::bind(&MdRobotMsg1Subscriber::topic_callback, this, std::placeholders::_1));
  }

private:
  void topic_callback(const mui_md::msg::MdRobotMsg1::SharedPtr msg) const
  {
    RCLCPP_INFO(this->get_logger(), "Received: '%f'", msg->interval_time);
  }
  rclcpp::Subscription<mui_md::msg::MdRobotMsg1>::SharedPtr subscription_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MdRobotMsg1Subscriber>());
  rclcpp::shutdown();
  return 0;
}
