#include "rclcpp/rclcpp.hpp"
#include "mui_md/msg/md_robot_msg1.hpp"  // 새로 정의한 메시지 헤더

class MdRobotMsg1Publisher : public rclcpp::Node
{
public:
  MdRobotMsg1Publisher() : Node("md_robot_msg1_publisher")
  {
    publisher_ = this->create_publisher<mui_md::msg::MdRobotMsg1>("md_robot_msg1_topic", 10);
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(500),
      std::bind(&MdRobotMsg1Publisher::timer_callback, this));
  }

private:
  void timer_callback()
  {
    auto message = mui_md::msg::MdRobotMsg1();
    message.interval_time = 1.0;
    // 다른 필드도 적절히 설정
    RCLCPP_INFO(this->get_logger(), "Publishing: '%f'", message.interval_time);
    publisher_->publish(message);
  }
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<mui_md::msg::MdRobotMsg1>::SharedPtr publisher_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MdRobotMsg1Publisher>());
  rclcpp::shutdown();
  return 0;
}
