from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    # 파라미터 파일이 위치한 디렉토리 경로를 구함
    params_file_dir = get_package_share_directory('mui_md')
    params_file_path = os.path.join(params_file_dir, 'params', 'params.yaml')

    return LaunchDescription([
        Node(
            package='mui_md',  # 실행할 노드가 속한 패키지 이름
            executable='mui_md_node',  # 실행할 노드의 실행 파일 이름
            name='mui_md_node',  # 실행할 때 사용할 노드의 이름
            output='screen',  # 노드의 출력을 화면에 표시
            parameters=[params_file_path]  # 파라미터 파일 경로를 리스트로 전달
        )
    ])
