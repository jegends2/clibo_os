var searchData=
[
  ['ioexception_155',['IOException',['../classserial_1_1_i_o_exception.html#acb2f2cf7a5cc8090945f6cbfcef3ef1e',1,'serial::IOException::IOException(std::string file, int line, int errnum)'],['../classserial_1_1_i_o_exception.html#acc1d2c650832cc8127f2cd777072b2cd',1,'serial::IOException::IOException(std::string file, int line, const char *description)'],['../classserial_1_1_i_o_exception.html#af65196a71b800d11b5e5c367caf5b354',1,'serial::IOException::IOException(const IOException &amp;other)']]],
  ['isopen_156',['isOpen',['../classserial_1_1serial_1_1_serial_1_1_serial_impl.html#a78f28bc8e63ef24aa805178571f4b384',1,'serial::serial::Serial::SerialImpl::isOpen()'],['../classserial_1_1_serial.html#a5b4069da8ec84ee4331d0690b325d08d',1,'serial::Serial::isOpen()']]]
];
