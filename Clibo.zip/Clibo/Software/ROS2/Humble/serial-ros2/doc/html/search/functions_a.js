var searchData=
[
  ['read_165',['read',['../classserial_1_1serial_1_1_serial_1_1_serial_impl.html#ada61c83884f0f6350874fc32e640cbac',1,'serial::serial::Serial::SerialImpl::read()'],['../classserial_1_1_serial.html#a0261dbfb9361784ecb3eee98b85fa103',1,'serial::Serial::read(uint8_t *buffer, size_t size)'],['../classserial_1_1_serial.html#aa3795c6cbc96f504932dd02fd6e9538e',1,'serial::Serial::read(std::vector&lt; uint8_t &gt; &amp;buffer, size_t size=1)'],['../classserial_1_1_serial.html#ac47576244e34abc2e460ba99684c351f',1,'serial::Serial::read(std::string &amp;buffer, size_t size=1)'],['../classserial_1_1_serial.html#a6c71ad1cbacf86cead4d38b48c548405',1,'serial::Serial::read(size_t size=1)']]],
  ['readline_166',['readline',['../classserial_1_1_serial.html#a010b18ec545dfe1a7bb1c95be4bdaa54',1,'serial::Serial::readline(std::string &amp;buffer, size_t size=65536, std::string eol=&quot;\n&quot;)'],['../classserial_1_1_serial.html#a04177f637cc02f92ec0492d377528b2a',1,'serial::Serial::readline(size_t size=65536, std::string eol=&quot;\n&quot;)']]],
  ['readlines_167',['readlines',['../classserial_1_1_serial.html#a99f77b9bbdc128b6704cc59db77686c5',1,'serial::Serial']]],
  ['readlock_168',['readLock',['../classserial_1_1serial_1_1_serial_1_1_serial_impl.html#a284eeedc3dd686ecef0fdcfd83bebc54',1,'serial::serial::Serial::SerialImpl']]],
  ['readunlock_169',['readUnlock',['../classserial_1_1serial_1_1_serial_1_1_serial_impl.html#ab6533e884ba609a1dd6a88b7964d8b52',1,'serial::serial::Serial::SerialImpl']]],
  ['reconfigureport_170',['reconfigurePort',['../classserial_1_1serial_1_1_serial_1_1_serial_impl.html#ad006a2392150daddfa43ae288259c07d',1,'serial::serial::Serial::SerialImpl']]],
  ['remaining_171',['remaining',['../classserial_1_1_millisecond_timer.html#a3786e2c6d8614adff0da39e1d1a2b0e3',1,'serial::MillisecondTimer']]],
  ['run_172',['run',['../serial__example_8cc.html#ac1f545534cdaab9094198a5dc2c2a79f',1,'serial_example.cc']]]
];
