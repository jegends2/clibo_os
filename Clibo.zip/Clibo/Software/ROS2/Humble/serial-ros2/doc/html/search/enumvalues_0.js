var searchData=
[
  ['eightbits_218',['eightbits',['../namespaceserial.html#a00b3281fa11cea770c0b0c8a106080f8a47f14d952cf9bed6c3f7ae5985161990',1,'serial']]]
];
