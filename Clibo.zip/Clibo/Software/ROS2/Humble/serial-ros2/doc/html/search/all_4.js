var searchData=
[
  ['eightbits_4',['eightbits',['../namespaceserial.html#a00b3281fa11cea770c0b0c8a106080f8a47f14d952cf9bed6c3f7ae5985161990',1,'serial']]],
  ['enumerate_5fports_5',['enumerate_ports',['../serial__example_8cc.html#a996e0d351ea6c804947e9533581765ea',1,'serial_example.cc']]]
];
