var searchData=
[
  ['close_2',['close',['../classserial_1_1serial_1_1_serial_1_1_serial_impl.html#a2608096ba0d17127b17484fc9481833a',1,'serial::serial::Serial::SerialImpl::close()'],['../classserial_1_1_serial.html#afbe59407e718bc3d22ea4a67b304db6c',1,'serial::Serial::close()']]]
];
