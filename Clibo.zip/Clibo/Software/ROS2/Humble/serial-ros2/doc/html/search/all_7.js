var searchData=
[
  ['hardware_5fid_26',['hardware_id',['../structserial_1_1_port_info.html#a7d55368e1a4e6ccc9da6f4d339524837',1,'serial::PortInfo']]]
];
