var searchData=
[
  ['portnotopenedexception_163',['PortNotOpenedException',['../classserial_1_1_port_not_opened_exception.html#acd2213fae864534eae6a580f74c5ab1b',1,'serial::PortNotOpenedException::PortNotOpenedException(const char *description)'],['../classserial_1_1_port_not_opened_exception.html#ae8b466d10d496a53ed8e9f949e9e628c',1,'serial::PortNotOpenedException::PortNotOpenedException(const PortNotOpenedException &amp;other)']]],
  ['print_5fusage_164',['print_usage',['../serial__example_8cc.html#ae5ad5cbeccaedc03a48d3c7eaa803e79',1,'serial_example.cc']]]
];
