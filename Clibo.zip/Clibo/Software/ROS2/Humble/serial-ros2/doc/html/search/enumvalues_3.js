var searchData=
[
  ['sevenbits_228',['sevenbits',['../namespaceserial.html#a00b3281fa11cea770c0b0c8a106080f8a7cf0a3607e326ff6736941008ea8174d',1,'serial']]],
  ['sixbits_229',['sixbits',['../namespaceserial.html#a00b3281fa11cea770c0b0c8a106080f8a608eb93b80fe8531d626b4e588c5bc8b',1,'serial']]],
  ['stopbits_5fone_230',['stopbits_one',['../namespaceserial.html#af5b116611d6628a3aa8f788fdc09f469ab70806555a14cb43e5cc43f6f3d01157',1,'serial']]],
  ['stopbits_5fone_5fpoint_5ffive_231',['stopbits_one_point_five',['../namespaceserial.html#af5b116611d6628a3aa8f788fdc09f469abb25fb831662d361d99cf12fb0da45ec',1,'serial']]],
  ['stopbits_5ftwo_232',['stopbits_two',['../namespaceserial.html#af5b116611d6628a3aa8f788fdc09f469ae0b1b8af1ece65afeacbe9fff198fa47',1,'serial']]]
];
