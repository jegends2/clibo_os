var searchData=
[
  ['timeout_190',['Timeout',['../structserial_1_1_timeout.html#a1a454b17f5d653b8e1b04b3ec2fead59',1,'serial::Timeout']]],
  ['timespec_5ffrom_5fms_191',['timespec_from_ms',['../unix_8cc.html#a89267c1a694b6017c261da0387291546',1,'unix.cc']]]
];
